package modeler;

public class Util {
	public static void trace(String s) {
		System.out.println("[TRACE] " + s);
	}
}
