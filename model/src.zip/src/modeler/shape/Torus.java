package modeler.shape;

public class Torus extends Shape {
	/**
	 * Required for IO
	 */
	public Torus() {}

	/**
	 * @see modeler.shape.Shape#buildMesh()
	 */
	public void buildMesh() {
		// TODO: Part 2: Implement this method
		throw new UnsupportedOperationException();
	}
}
