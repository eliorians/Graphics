package modeler.shape;

/**
 * @author ags
 */
public class Sphere extends Shape {
	/**
	 * Required for IO
	 */
	public Sphere() {}

	/**
	 * @see modeler.shape.Shape#buildMesh()
	 */
	public void buildMesh() {
		//TODO: Part 2: Implement this method.
		throw new UnsupportedOperationException();
	}

}
