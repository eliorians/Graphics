package modeler.shape;

/**
 * @author ags
 */
public class Cylinder extends Shape {
	/**
	 * Required for IO
	 */
	public Cylinder() {}

	/**
	 * @see modeler.shape.Shape#buildMesh()
	 */
	public void buildMesh() {
		// TODO: Part 2: Implement this method
		throw new UnsupportedOperationException();
	}
}
